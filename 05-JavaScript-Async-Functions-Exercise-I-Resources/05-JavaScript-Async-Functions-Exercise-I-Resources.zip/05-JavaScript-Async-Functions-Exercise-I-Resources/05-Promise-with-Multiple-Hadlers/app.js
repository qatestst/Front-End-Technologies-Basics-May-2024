function promiseWithMultipleHandlers() {
    // TODO
}