async function chainedPromisesAsync() {
    // TODO
}