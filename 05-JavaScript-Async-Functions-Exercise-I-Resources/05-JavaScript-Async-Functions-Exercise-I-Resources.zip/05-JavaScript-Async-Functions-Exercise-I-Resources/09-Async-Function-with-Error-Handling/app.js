async function promiseRejectionAsync() {
   // TODO
}