function promiseRejection() {
    // TODO
}