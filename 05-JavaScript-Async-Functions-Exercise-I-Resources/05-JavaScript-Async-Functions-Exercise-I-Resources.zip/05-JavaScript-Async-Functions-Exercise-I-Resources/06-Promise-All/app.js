function allPromise() {
    // TODO
}