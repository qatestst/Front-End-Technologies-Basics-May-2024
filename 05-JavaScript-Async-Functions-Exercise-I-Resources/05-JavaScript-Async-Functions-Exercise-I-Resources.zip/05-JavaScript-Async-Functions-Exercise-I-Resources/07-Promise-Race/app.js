function racePromise() {
    // TODO
}