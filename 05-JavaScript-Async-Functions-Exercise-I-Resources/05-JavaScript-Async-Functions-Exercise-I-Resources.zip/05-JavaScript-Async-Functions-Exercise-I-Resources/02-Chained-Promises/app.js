function chainedPromises() {
    // TODO
}