function simplePromise() {
    // TODO
}