async function simplePromiseAsync() {
    // TODO
}