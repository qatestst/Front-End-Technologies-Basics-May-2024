async function startQuiz() {
    // TODO
}