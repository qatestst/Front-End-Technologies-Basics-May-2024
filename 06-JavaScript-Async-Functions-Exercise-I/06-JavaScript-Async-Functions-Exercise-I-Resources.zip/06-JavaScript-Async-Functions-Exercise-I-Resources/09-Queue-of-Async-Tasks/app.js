class AsyncQueue {
    // TODO...
}

function startQueue() {
    // TODO...
}