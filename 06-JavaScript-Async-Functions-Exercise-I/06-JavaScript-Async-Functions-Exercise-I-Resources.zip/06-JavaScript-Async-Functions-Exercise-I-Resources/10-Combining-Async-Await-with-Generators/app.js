function asyncGenerator(generatorFunc) {
    // TODO...
}

function startAsyncGenerator() {
    // TODO...
}